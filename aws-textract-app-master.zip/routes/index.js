const express = require('express')
const router = express.Router()
const formidable = require('formidable')
const AWS = require('aws-sdk')
const fs = require('fs')
const mysql = require('mysql')
const textractHelper = require('aws-textract-helper')
require('dotenv').config()

var connection = mysql.createConnection({
    host: "localhost",
    user:"root",
    password:"",
    database:"textract"
})

/* GET home page. */
router.get('/', (req, res, next) => {
  res.render('index', { title: 'Textract Uploader' })
})

router.post('/fileupload', (req, res, next) => {
  // Upload logic
  const form = new formidable.IncomingForm()
  form.parse(req, async (err, fields, files) => {
    if (err) {
      console.error(err)
    }
    const fileContent = fs.readFileSync(files.filetoupload.path)
    const s3Params = {
      Bucket: 'ep-textract',
      Key: `${Date.now().toString()}-${files.filetoupload.name}`,
      Body: fileContent,
      ContentType: files.filetoupload.type,
      ACL: 'public-read'
    }
    const s3Content = await s3Upload(s3Params)
    const textractData = await documentExtract(s3Content.Key)

    const formData = textractHelper.createForm(textractData, { trimChars: [':', ' '] })
    res.render('fileupload', { title: 'Upload Results', formData })
	
    
    
	const queryString = `INSERT INTO is_client_info_table_info_step_1 (client_reg_no, step_1_client_first_name, step_1_client_last_name, step_1_client_address) VALUES ('${formData['client_reg_no']}', '${formData['step_1_client_first_name']}', '${formData['step_1_client_last_name']}', '${formData['step_1_client_address']}')`;

    connection.query(queryString, function (err, fields) {
    if (err) {
        // Throw your error output here.
        console.log("An error occurred.");
    } else {
        // Throw a success message here.
        console.log("record successfully inserted into db");
    }
	})
  })
})

async function s3Upload (params) {
  const s3 = new AWS.S3({
    accessKeyId: 'AKIAXCJGWDPY66XLD3FY',
    secretAccessKey: '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'
  })
  return new Promise(resolve => {
    s3.upload(params, (err, data) => {
      if (err) {
        console.error(err)
        resolve(err)
      } else {
        resolve(data)
      }
    })
  })
}

async function documentExtract (key) {
  return new Promise(resolve => {
    var textract = new AWS.Textract({
      region: 'us-east-1',
      endpoint: `https://textract.us-east-1.amazonaws.com/`,
      accessKeyId: 'AKIAXCJGWDPY66XLD3FY',
      secretAccessKey: '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'
    })
    var params = {
      Document: {
        S3Object: {
          Bucket: 'ep-textract',
          Name: key
        }
      },
      FeatureTypes: ['FORMS']
    }

    textract.analyzeDocument(params, (err, data) => {
      if (err) {
        return resolve(err)
      } else {
        resolve(data)
      }
    })
  })
}

module.exports = router
